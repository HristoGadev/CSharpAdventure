﻿namespace DefiningClasses
{
    public class Cargo
    {
        public int Weigth { get; set; }
        public string Type { get; set; }
    }
}