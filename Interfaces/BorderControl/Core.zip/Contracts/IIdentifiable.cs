﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl.Contracts
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
